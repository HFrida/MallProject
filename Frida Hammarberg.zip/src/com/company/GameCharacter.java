package com.company;

public class GameCharacter {

    protected int xPos;
    protected int yPos;

    public GameCharacter(int yPos, int xPos) {
        this.yPos = yPos;
        this.xPos = xPos;
    }
}
