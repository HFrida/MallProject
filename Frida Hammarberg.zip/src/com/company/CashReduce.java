package com.company;

public interface CashReduce {

    int cashReduceMethod(int cash);
}
